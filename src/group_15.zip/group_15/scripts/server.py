#!/usr/bin/env python
# encoding: utf-8

__copyright__ = "Copyright 2019, AAIR Lab, ASU"
__authors__ = ["Naman Shah", "Ketan Patil"]
__credits__ = ["Siddharth Srivastava"]
__license__ = "MIT"
__version__ = "1.0"
__maintainers__ = ["Pulkit Verma", "Abhyudaya Srinet"]
__contact__ = "aair.lab@asu.edu"
__docformat__ = 'reStructuredText'

from group_15.srv import *
import rospy
from mazeGenerator import *
from action_server import RobotActionsServer
import os

root_path = os.path.abspath(os.path.join(os.path.dirname(__file__), os.path.pardir))

books = None
mazeInfo = None

def check_is_edge(edge, valueFlag):
    global mazeInfo
    invalid_edges = mazeInfo
    if valueFlag == "changedValuesLater":
        if edge[2] <= -3.0 or edge[2] > 4.1 or edge[3] <= -4.0 or edge[3] >= 10:
            return False
    elif valueFlag == "changedValuesBefore":
        if edge[0] <= -3.0 or edge[0] > 4.1 or edge[1] < -4.0 or edge[1] >= 10:
            return False

    if edge in invalid_edges:
        return False
    else:
        return True


def handle_get_successor(req):
    global mazeInfo
    directionList = ["NORTH", "EAST", "SOUTH", "WEST"]
    x_cord, y_cord, direction, action = req.x, req.y, req.direction, req.action

    # Checking requested action and making changes in states
    if action == 'TurnCW':
        index = directionList.index(req.direction)
        direction = directionList[(index + 1) % 4]
        g_cost = 2

    elif action == 'TurnCCW':
        index = directionList.index(req.direction)
        direction = directionList[(index - 1) % 4]
        g_cost = 2

    elif action == 'MoveF':
        if direction == "NORTH":
            y_cord += 0.5
        elif direction == "EAST":
            x_cord += 0.5
        elif direction == "SOUTH":
            y_cord -= 0.5
        elif direction == "WEST":
            x_cord -= 0.5
        g_cost = 1

    elif action == 'MoveB':
        if direction == "NORTH":
            y_cord -= 0.5
        elif direction == "EAST":
            x_cord -= 0.5
        elif direction == "SOUTH":
            y_cord += 0.5
        elif direction == "WEST":
            x_cord += 0.5
        g_cost = 3

    isValidEdge1 = check_is_edge((req.x, req.y, x_cord, y_cord), "changedValuesLater")
    isValidEdge2 = check_is_edge((x_cord, y_cord, req.x, req.y), "changedValuesBefore")

    if not isValidEdge1 and isValidEdge2:
        return GetSuccessorResponse(-1, -1, direction, -1)

    return GetSuccessorResponse(x_cord, y_cord, direction, g_cost)


def handle_get_initial_state(req):
    return GetInitialStateResponse(0, 0, "EAST")


def server():
    rospy.Service('get_successor', GetSuccessor, handle_get_successor)
    rospy.Service('get_initial_state', GetInitialState, handle_get_initial_state)
    print "Ready!"
    rospy.spin()


if __name__ == "__main__":
    mazeInfo = generate_blocked_edges()
    rospy.init_node('server')
    with open(root_path + '/objects_new.json') as json_file:
        try:
            books = json.load(json_file, parse_float=float)
        except (ValueError, KeyError, TypeError):
            print "JSON error"
    RobotActionsServer(books)
    server()
