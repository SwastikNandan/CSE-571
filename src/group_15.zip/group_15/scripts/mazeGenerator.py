#!/usr/bin/env python
# encoding: utf-8

import json
import os

dirname = os.path.dirname(__file__)
filename = os.path.join(dirname, "../objects_new.json")
with open(filename) as json_file:
    try:
        objects = json.load(json_file, parse_float=float)
    except (ValueError, KeyError, TypeError):
        print "JSON error"


def generate_blocked_edges():
    blocked_edges = set()
    odd_table_loc = [objects['tables']['table_1']['loc'], objects['tables']['table_3']['loc']]
    even_table_loc = [objects['tables']['table_2']['loc'], objects['tables']['table_4']['loc']]

    for i in range(len(odd_table_loc)):
        odd_table_loc[i] = [round(odd_table_loc[i][0] * 2) / 2, round(odd_table_loc[i][1] * 2) / 2]
    for i in range(len(even_table_loc)):
        even_table_loc[i] = [round(even_table_loc[i][0] * 2) / 2, round(even_table_loc[i][1] * 2) / 2]
    odd_table_loc[1][0] = odd_table_loc[1][0] + 0.5

    all_table_loc = odd_table_loc + even_table_loc
    for i in range(4):
        table_loc = all_table_loc[i]
        blocked_edges.add((table_loc[0], table_loc[1], table_loc[0], table_loc[1] + 0.5))
        blocked_edges.add((table_loc[0], table_loc[1] + 0.5, table_loc[0], table_loc[1]))
        blocked_edges.add((table_loc[0], table_loc[1], table_loc[0], table_loc[1] - 0.5))
        blocked_edges.add((table_loc[0], table_loc[1] - 0.5, table_loc[0], table_loc[1]))
        blocked_edges.add((table_loc[0], table_loc[1], table_loc[0] + 0.5, table_loc[1]))
        blocked_edges.add((table_loc[0] + 0.5, table_loc[1], table_loc[0], table_loc[1]))
        blocked_edges.add((table_loc[0], table_loc[1], table_loc[0] - 0.5, table_loc[1]))
        blocked_edges.add((table_loc[0] - 0.5, table_loc[1], table_loc[0], table_loc[1]))
        blocked_edges.add((table_loc[0], table_loc[1] - 0.5, table_loc[0] - 0.5, table_loc[1] - 0.5))
        blocked_edges.add((table_loc[0] - 0.5, table_loc[1] - 0.5, table_loc[0], table_loc[1] - 0.5))
        blocked_edges.add((table_loc[0], table_loc[1] - 0.5, table_loc[0] + 0.5, table_loc[1] - 0.5))
        blocked_edges.add((table_loc[0] + 0.5, table_loc[1] - 0.5, table_loc[0], table_loc[1] - 0.5))

    for i in range(2):
        table_loc = odd_table_loc[i]
        blocked_edges.add((table_loc[0] - 0.5, table_loc[1], table_loc[0] - 0.5, table_loc[1] + 0.5))
        blocked_edges.add((table_loc[0] - 0.5, table_loc[1] + 0.5, table_loc[0] - 0.5, table_loc[1]))
        blocked_edges.add((table_loc[0] - 0.5, table_loc[1], table_loc[0] - 0.5, table_loc[1] - 0.5))
        blocked_edges.add((table_loc[0] - 0.5, table_loc[1] - 0.5, table_loc[0] - 0.5, table_loc[1]))
        blocked_edges.add((table_loc[0] - 0.5, table_loc[1] - 0.5, table_loc[0] - 1.0, table_loc[1] - 0.5))
        blocked_edges.add((table_loc[0] - 1.0, table_loc[1] - 0.5, table_loc[0] - 0.5, table_loc[1] - 0.5))
        blocked_edges.add((table_loc[0] - 0.5, table_loc[1] - 0.5, table_loc[0] - 0.5, table_loc[1] - 1.0))
        blocked_edges.add((table_loc[0] - 0.5, table_loc[1] - 1.0, table_loc[0] - 0.5, table_loc[1] - 0.5))

    for i in range(2):
        table_loc = even_table_loc[i]
        blocked_edges.add((table_loc[0] + 0.5, table_loc[1], table_loc[0] + 0.5, table_loc[1] + 0.5))
        blocked_edges.add((table_loc[0] + 0.5, table_loc[1] + 0.5, table_loc[0] + 0.5, table_loc[1]))
        blocked_edges.add((table_loc[0] + 0.5, table_loc[1], table_loc[0] + 0.5, table_loc[1] - 0.5))
        blocked_edges.add((table_loc[0] + 0.5, table_loc[1] - 0.5, table_loc[0] + 0.5, table_loc[1]))
        blocked_edges.add((table_loc[0] + 0.5, table_loc[1] - 0.5, table_loc[0] + 1.0, table_loc[1] - 0.5))
        blocked_edges.add((table_loc[0] + 1.0, table_loc[1] - 0.5, table_loc[0] + 0.5, table_loc[1] - 0.5))
        blocked_edges.add((table_loc[0] + 0.5, table_loc[1] - 0.5, table_loc[0] + 0.5, table_loc[1] - 1.0))
        blocked_edges.add((table_loc[0] + 0.5, table_loc[1] - 1.0, table_loc[0] + 0.5, table_loc[1] - 0.5))

        return blocked_edges
