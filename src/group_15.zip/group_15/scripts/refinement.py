#!/usr/bin/env python
# encoding: utf-8

__copyright__ = "Copyright 2019, AAIR Lab, ASU"
__authors__ = ["Abhyudaya Srinet", "Pulkit Verma"]
__credits__ = ["Siddharth Srivastava"]
__license__ = "MIT"
__version__ = "1.0"
__maintainers__ = ["Pulkit Verma", "Abhyudaya Srinet"]
__contact__ = "aair.lab@asu.edu"
__docformat__ = 'reStructuredText'

import rospy
import problem
import heapq
import argparse
import os
import json
from std_msgs.msg import String
import Queue

ROOT_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), os.path.pardir))
DOMAIN_FILE_PATH = ROOT_PATH + "/domain.pddl"
PROBLEM_FILE_PATH = ROOT_PATH + "/problem%d.pddl"
FF_PATH = ROOT_PATH + "/planners/FF/ff"

parser = argparse.ArgumentParser(formatter_class=argparse.RawTextHelpFormatter)
parser.add_argument('-step', help="Step to execute:\n1. Generate plan\n2. Perform downward refinement and execute",
                    metavar='1', action='store', dest='step', default="1", type=int)


class Refine:

    def __init__(self, plan_files):
        rospy.init_node('listener', anonymous=True)
        self.status_subscriber = rospy.Subscriber('/status', String, self.status_callback)
        self.helper = problem.Helper()
        self.action_index = 0
        self.actions_queue = self.refine_plan(plan_files)
        self.execute_action()
        rospy.spin()

    def status_callback(self, data):
        if (data.data == "Idle"):
            self.execute_action()

    def execute_action(self):
        helper = problem.Helper()
        if (self.action_index >= len(self.actions_queue)):
            return
        action = self.actions_queue[self.action_index]
        self.action_index += 1
        print("Executing ", action[0])
        if action[0] == 'move':
            helper.execute_move_action(action[1])
        elif action[0] == 'pick' or action[0] == 'collect':
            helper.execute_pick_action(action[1][0], action[1][1])
        elif action[0] == 'serve' or action[0] == 'throw':
            helper.execute_place_action(action[1][0], action[1][1], action[1][2])
        return

    def refine_plan(self, plan_files):
        time_in_integer = {'five': 5, 'ten': 10, 'fifteen': 15, 'twenty': 20, 'twentyfive': 25, 'thirty': 30,
                           'thirtyfive': 35, 'forty': 40}
        action_list = []
        objects_dict = self.parse_object_data()
        helper = problem.Helper()
        current_state = helper.get_initial_state()
        plan_sequence = []
        for i in range(len(plan_files)):
            with open(plan_files[i]) as f:
                plan_sequence.append(f.readlines()[:-1])
        action_queue = Queue.PriorityQueue()
        for plan in plan_sequence:
            pick_action = plan[:4]
            pick_action_time = time_in_integer[plan[1].split(' ')[-1][:-2]]
            action_queue.put([pick_action_time, pick_action])

            collect_action = plan[4:]
            collect_action_time = time_in_integer[plan[4].split(' ')[-1][:-2]]
            action_queue.put([collect_action_time, collect_action])

        while not action_queue.empty():
            action_sequence = action_queue.get()[1]
            for action_info in action_sequence:
                action_info_list = action_info[1:-2].split()
                action = action_info_list[0]
                if action == 'pick':
                    bowl_name = action_info_list[1]
                    action_params = (bowl_name, current_state)
                    action_list.append((action, action_params))
                elif action == 'serve':
                    bowl_name = action_info_list[1]
                    table_name = action_info_list[3]
                    action_params = (bowl_name, table_name, current_state)
                    action_list.append((action, action_params))
                elif action == 'move':
                    destination_locations = objects_dict.get(action_info_list[-1][:-4]).get('load_loc')
                    moves_list, destination_state, goal_reached = self.get_path(current_state, destination_locations)
                    if not goal_reached:
                        return []
                    action_list.append((action, moves_list))
                    current_state = destination_state
                elif action == 'throw':
                    bowl_name = action_info_list[1]
                    bin_name = action_info_list[2]
                    action_params = (bowl_name, bin_name, current_state)
                    action_list.append((action, action_params))
                elif action == 'collect':
                    bowl_name = action_info_list[1]
                    table_name = action_info_list[2]
                    current_bot_location = (current_state.x, current_state.y)
                    table_load_location = objects_dict.get(table_name).get('load_loc')
                    if current_bot_location not in table_load_location:
                        moves_list, destination_state, goal_reached = self.get_path(current_state, table_load_location)
                        if not goal_reached:
                            return []
                        action_list.append(('move', moves_list))
                        current_state = destination_state
                    action_params = (bowl_name, current_state)
                    action_list.append((action, action_params))
        print(action_list)
        return action_list

    def parse_object_data(self):
        object_data_dict = {}
        with open(ROOT_PATH + '/objects_new.json') as json_file:
            try:
                objects = json.load(json_file, parse_float=float)
                for key, value in objects.iteritems():
                    for k, v in value.iteritems():
                        object_data_dict[k] = v
            except (ValueError, KeyError, TypeError):
                print "JSON error"
        return object_data_dict

    def is_goal_state(self, current_state, goal_state):
        if (
                current_state.x == goal_state.x and current_state.y == goal_state.y and current_state.orientation == goal_state.orientation):
            return True
        return False

    def get_manhattan_distance(self, from_state, to_state):
        return abs(from_state.x - to_state.x) + abs(from_state.y - to_state.y)

    def build_goal_states(self, locations):
        states = []
        for location in locations:
            states.append(problem.State(location[0], location[1], "EAST"))
            states.append(problem.State(location[0], location[1], "WEST"))
            states.append(problem.State(location[0], location[1], "NORTH"))
            states.append(problem.State(location[0], location[1], "SOUTH"))
        return states

    def get_path(self, init_state, goal_locations):
        final_state = None
        goal_states = self.build_goal_states(goal_locations)
        goal_reached = False
        for goal_state in goal_states:  # search for any of the load locations
            possible_actions = self.helper.get_actions()
            action_list = []

            state_queue = []
            heapq.heappush(state_queue, (self.get_manhattan_distance(init_state, goal_state), 0, (init_state, [])))
            visited = []
            state_cost = {}
            insert_order = 0

            while len(state_queue) > 0:
                top_item = heapq.heappop(state_queue)
                current_cost = top_item[0]
                current_state = top_item[2][0]
                current_actions = top_item[2][1]

                if (current_state in visited):
                    continue

                if (self.is_goal_state(current_state, goal_state)):
                    goal_reached = True
                    break

                visited.append(current_state)
                for action in possible_actions:
                    nextstate, cost = self.helper.get_successor(current_state, action)
                    cost = self.get_manhattan_distance(nextstate, goal_state)  # manhattan distance heuristc
                    key = (nextstate.x, nextstate.y, nextstate.orientation)
                    if (nextstate.x == -1 and nextstate.y == -1):
                        continue
                    # if a new state is found then add to queue
                    if (nextstate not in visited and key not in state_cost.keys()):
                        heapq.heappush(state_queue, (cost, insert_order, (nextstate, current_actions + [action])))
                        insert_order += 1
                        state_cost[key] = cost

            if (self.is_goal_state(current_state, goal_state)):
                action_list = current_actions
                final_state = current_state
                goal_reached = True
                break

        return action_list, final_state, goal_reached


def generate_plan(problem_file_path):
    command = FF_PATH + " -o " + DOMAIN_FILE_PATH + " -f " + problem_file_path + " "
    os.system(command)


if __name__ == "__main__":
    args = parser.parse_args()
    plan_files = []
    if args.step == 1:
        for i in range(1, 5):
            problem_file_path = PROBLEM_FILE_PATH % i
            generate_plan(problem_file_path)
    elif args.step == 2:
        for i in range(1, 5):
            plan_files.append((PROBLEM_FILE_PATH % i) + ".soln")
        try:
            Refine(plan_files)
        except rospy.ROSInterruptException:
            pass
